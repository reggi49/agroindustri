h1>Congrats!</h1>
<p>Your account has not been created. <?php echo anchor('login', 'Login Now');?></p>