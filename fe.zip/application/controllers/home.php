<?php

class Home extends Controller{

	function home()
	{
		$this->load->view('home')
	}
}